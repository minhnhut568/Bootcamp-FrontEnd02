// StateLess Component là component được viết dưới dạng function
function StateLess() {
  return (
    <div>
      <h2>StateLess</h2>
    </div>
  );
}

export default StateLess;
