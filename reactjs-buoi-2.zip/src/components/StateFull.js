// StateFull Component là component được viết dưới dạng class
import React, { Component } from "react";
class StateFull extends Component {
  /**
   *render là phương thức đưa html ra màn hình
   */
  render() {
    return (
      <div>
        <h2>StateFull</h2>
      </div>
    );
  }
}
export default StateFull;
